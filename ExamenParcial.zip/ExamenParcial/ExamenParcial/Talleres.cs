﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenParcial
{
    class Talleres
    {
        int codigo;
        string nombreT;
        int costo;

        public int Codigo { get => codigo; set => codigo = value; }
        public string NombreT { get => nombreT; set => nombreT = value; }
        public int Costo { get => costo; set => costo = value; }
    }
}
