﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExamenParcial
{
    public partial class Form1 : Form
    {

        Datos datos = new Datos();
        Talleres talleres = new Talleres();
        Inscripciones Inscripciones = new Inscripciones();

        List<Datos> datos1 = new List<Datos>();
        List<Talleres> taller1 = new List<Talleres>();
        List<Inscripciones> inscripcion1 = new List<Inscripciones>();
        public Form1()
        {
            InitializeComponent();

            buscardatos();
            buscartalleres();

            foreach (Datos alumno in datos1)
            {
                comboBox1.Items.Add(alumno.Nombre);
            }

            foreach (Talleres taller in taller1)
            {
                comboBox2.Items.Add(taller.NombreT);
            }
        }

        private void buscardatos()
        {
            string fileName = "Datos.txt";

            FileStream stream = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            StreamReader reader = new StreamReader(stream);



            while (reader.Peek() > -1)
            {
                Datos datos = new Datos();
                datos.Dpi = reader.ReadLine();
                datos.Nombre = reader.ReadLine();
                datos.Direccion = reader.ReadLine();

                datos1.Add(datos);


            }

            reader.Close();

        }

        private void buscartalleres()
        {
            string fileName = "Talleres.txt";

            FileStream stream = new FileStream(fileName, FileMode.Open, FileAccess.Read);
            StreamReader reader = new StreamReader(stream);



            while (reader.Peek() > -1)
            {
                Talleres talleres = new Talleres();

                talleres.Codigo = Convert.ToInt32(reader.ReadLine());
                talleres.NombreT = reader.ReadLine();
                talleres.Costo = Convert.ToInt32(reader.ReadLine());

                taller1.Add(talleres);


            }

            reader.Close();

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedIndex = comboBox1.SelectedIndex;
            if (selectedIndex >= 0 && selectedIndex < datos1.Count)
            {
                Datos alumnoSeleccionado = datos1[selectedIndex];
                MessageBox.Show($"Nombre: {alumnoSeleccionado.Nombre}\nDPI: {alumnoSeleccionado.Dpi}\nDirección: {alumnoSeleccionado.Direccion}");
            }

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedIndex = comboBox2.SelectedIndex;
            if (selectedIndex >= 0 && selectedIndex < taller1.Count)
            {
                Talleres tallerSeleccionado = taller1[selectedIndex];
                MessageBox.Show($"Taller: {tallerSeleccionado.NombreT}\nCódigo: {tallerSeleccionado.Codigo}\nCosto: {tallerSeleccionado.Costo}");
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string nombreAlumno = comboBox1.SelectedItem.ToString();

            string nombreTaller = comboBox2.SelectedItem.ToString();

            Inscripciones nuevaInscripcion = new Inscripciones
            {
                NombreAlumno = nombreAlumno,
                NombreTaller = nombreTaller,
                Fecha = DateTime.Now
            };

            inscripcion1.Add(nuevaInscripcion);

            MessageBox.Show($"{nombreAlumno} inscrito a {nombreTaller} a las {DateTime.Now}");


            dataGridView1.DataSource = null;
            dataGridView1.DataSource = inscripcion1;
            dataGridView1.Refresh();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.Rows.Count > 0)
            {
                int columnIndex = dataGridView1.Columns["NombreTaller"].Index;

                inscripcion1 = inscripcion1.OrderBy(inscripcion => inscripcion.NombreTaller).ToList();

                dataGridView1.DataSource = null;
                dataGridView1.DataSource = inscripcion1;
            }
            else
            {
                MessageBox.Show("No hay datos para ordenar.");
            }
        }
    }
}