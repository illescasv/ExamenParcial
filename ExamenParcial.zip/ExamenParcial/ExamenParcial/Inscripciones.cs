﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExamenParcial
{
    class Inscripciones
    {

        DateTime fecha;
        string nombrealumno;
        string nombretaller;

        public DateTime Fecha { get => fecha; set => fecha = value; }

        public string NombreAlumno { get => nombrealumno; set => nombrealumno = value; }
        public string NombreTaller { get => nombretaller; set => nombretaller = value; }
    }
}
